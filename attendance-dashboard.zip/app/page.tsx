"use client"

import { useState } from "react"
import {
  Users,
  Clock,
  Search,
  Download,
  CheckCircle,
  AlertCircle,
  Calendar,
  Plus,
  Bell,
  LogIn,
  LogOut,
  Briefcase,
  Target,
  UserPlus,
  ClipboardList,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"

// Comprehensive Employee Database (25 employees)
const allEmployees = [
  // AI Team (8 employees)
  {
    id: 1,
    name: "Sarah Johnson",
    team: "AI Team",
    position: "AI Team Lead",
    email: "sarah.johnson@company.com",
    phone: "+1 (555) 123-4567",
    checkIn: "08:30 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 30m",
    activeTasks: 3,
    overdueTasks: 1,
    leaveStatus: "available",
    joinDate: "2022-01-15",
    department: "Technology",
    salary: "$120,000",
    skills: ["Machine Learning", "Python", "TensorFlow", "Leadership"],
  },
  {
    id: 2,
    name: "John Smith",
    team: "AI Team",
    position: "ML Engineer",
    email: "john.smith@company.com",
    phone: "+1 (555) 123-4568",
    checkIn: "09:15 AM",
    checkOut: "-",
    status: "present",
    statusType: "late",
    hoursWorked: "0h 45m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-03-20",
    department: "Technology",
    salary: "$95,000",
    skills: ["Deep Learning", "PyTorch", "Computer Vision", "NLP"],
  },
  {
    id: 3,
    name: "Lisa Garcia",
    team: "AI Team",
    position: "Data Scientist",
    email: "lisa.garcia@company.com",
    phone: "+1 (555) 123-4569",
    checkIn: "-",
    checkOut: "-",
    status: "absent",
    statusType: "absent",
    hoursWorked: "0h 0m",
    activeTasks: 1,
    overdueTasks: 2,
    leaveStatus: "on-leave",
    joinDate: "2021-11-10",
    department: "Technology",
    salary: "$90,000",
    skills: ["Data Analysis", "R", "Statistics", "Visualization"],
  },
  {
    id: 4,
    name: "Alex Rodriguez",
    team: "AI Team",
    position: "Senior ML Engineer",
    email: "alex.rodriguez@company.com",
    phone: "+1 (555) 123-4570",
    checkIn: "08:45 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 15m",
    activeTasks: 4,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2021-08-05",
    department: "Technology",
    salary: "$105,000",
    skills: ["MLOps", "Kubernetes", "AWS", "Model Deployment"],
  },
  {
    id: 5,
    name: "Emma Chen",
    team: "AI Team",
    position: "AI Research Scientist",
    email: "emma.chen@company.com",
    phone: "+1 (555) 123-4571",
    checkIn: "08:00 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "2h 0m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-06-12",
    department: "Technology",
    salary: "$110,000",
    skills: ["Research", "Neural Networks", "Publications", "Innovation"],
  },
  {
    id: 6,
    name: "Ryan Park",
    team: "AI Team",
    position: "ML Engineer",
    email: "ryan.park@company.com",
    phone: "+1 (555) 123-4572",
    checkIn: "09:30 AM",
    checkOut: "-",
    status: "present",
    statusType: "late",
    hoursWorked: "0h 30m",
    activeTasks: 3,
    overdueTasks: 1,
    leaveStatus: "available",
    joinDate: "2023-02-28",
    department: "Technology",
    salary: "$88,000",
    skills: ["Python", "Scikit-learn", "Data Pipeline", "APIs"],
  },
  {
    id: 7,
    name: "Sophia Williams",
    team: "AI Team",
    position: "Data Engineer",
    email: "sophia.williams@company.com",
    phone: "+1 (555) 123-4573",
    checkIn: "08:15 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 45m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-09-14",
    department: "Technology",
    salary: "$92,000",
    skills: ["ETL", "Apache Spark", "SQL", "Data Warehousing"],
  },
  {
    id: 8,
    name: "Marcus Thompson",
    team: "AI Team",
    position: "Junior ML Engineer",
    email: "marcus.thompson@company.com",
    phone: "+1 (555) 123-4574",
    checkIn: "-",
    checkOut: "-",
    status: "absent",
    statusType: "absent",
    hoursWorked: "0h 0m",
    activeTasks: 1,
    overdueTasks: 0,
    leaveStatus: "sick-leave",
    joinDate: "2023-07-01",
    department: "Technology",
    salary: "$75,000",
    skills: ["Python", "Machine Learning", "Git", "Agile"],
  },

  // BA Team (7 employees)
  {
    id: 9,
    name: "Mike Davis",
    team: "BA Team",
    position: "BA Team Lead",
    email: "mike.davis@company.com",
    phone: "+1 (555) 123-4575",
    checkIn: "08:45 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 15m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2021-05-18",
    department: "Business",
    salary: "$115,000",
    skills: ["Business Analysis", "Requirements", "Stakeholder Management", "Leadership"],
  },
  {
    id: 10,
    name: "Tom Anderson",
    team: "BA Team",
    position: "Senior Business Analyst",
    email: "tom.anderson@company.com",
    phone: "+1 (555) 123-4576",
    checkIn: "08:15 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 45m",
    activeTasks: 3,
    overdueTasks: 1,
    leaveStatus: "available",
    joinDate: "2021-09-22",
    department: "Business",
    salary: "$98,000",
    skills: ["Process Mapping", "Documentation", "SQL", "Tableau"],
  },
  {
    id: 11,
    name: "Jennifer Lee",
    team: "BA Team",
    position: "Business Analyst",
    email: "jennifer.lee@company.com",
    phone: "+1 (555) 123-4577",
    checkIn: "09:00 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 0m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-04-11",
    department: "Business",
    salary: "$85,000",
    skills: ["Requirements Analysis", "User Stories", "Jira", "Agile"],
  },
  {
    id: 12,
    name: "Robert Kim",
    team: "BA Team",
    position: "Data Analyst",
    email: "robert.kim@company.com",
    phone: "+1 (555) 123-4578",
    checkIn: "08:30 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 30m",
    activeTasks: 4,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-12-05",
    department: "Business",
    salary: "$78,000",
    skills: ["Excel", "Power BI", "Data Visualization", "Statistics"],
  },
  {
    id: 13,
    name: "Amanda Foster",
    team: "BA Team",
    position: "Process Analyst",
    email: "amanda.foster@company.com",
    phone: "+1 (555) 123-4579",
    checkIn: "09:20 AM",
    checkOut: "-",
    status: "present",
    statusType: "late",
    hoursWorked: "0h 40m",
    activeTasks: 1,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2023-01-16",
    department: "Business",
    salary: "$82,000",
    skills: ["Process Improvement", "Lean Six Sigma", "Workflow Design", "Training"],
  },
  {
    id: 14,
    name: "Kevin Martinez",
    team: "BA Team",
    position: "Junior Business Analyst",
    email: "kevin.martinez@company.com",
    phone: "+1 (555) 123-4580",
    checkIn: "08:50 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 10m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2023-05-08",
    department: "Business",
    salary: "$68,000",
    skills: ["Requirements Gathering", "Testing", "Documentation", "Communication"],
  },
  {
    id: 15,
    name: "Rachel Green",
    team: "BA Team",
    position: "Systems Analyst",
    email: "rachel.green@company.com",
    phone: "+1 (555) 123-4581",
    checkIn: "-",
    checkOut: "-",
    status: "absent",
    statusType: "absent",
    hoursWorked: "0h 0m",
    activeTasks: 2,
    overdueTasks: 1,
    leaveStatus: "vacation",
    joinDate: "2022-08-30",
    department: "Business",
    salary: "$88,000",
    skills: ["System Integration", "Technical Analysis", "Database Design", "APIs"],
  },

  // HR Team (5 employees)
  {
    id: 16,
    name: "Emily Brown",
    team: "HR Team",
    position: "HR Manager",
    email: "emily.brown@company.com",
    phone: "+1 (555) 123-4582",
    checkIn: "09:30 AM",
    checkOut: "-",
    status: "present",
    statusType: "late",
    hoursWorked: "0h 30m",
    activeTasks: 1,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2020-11-03",
    department: "Human Resources",
    salary: "$105,000",
    skills: ["HR Management", "Recruitment", "Employee Relations", "Compliance"],
  },
  {
    id: 17,
    name: "Anna Martinez",
    team: "HR Team",
    position: "HR Specialist",
    email: "anna.martinez@company.com",
    phone: "+1 (555) 123-4583",
    checkIn: "09:00 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 0m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2021-07-19",
    department: "Human Resources",
    salary: "$72,000",
    skills: ["Onboarding", "Benefits Administration", "HRIS", "Training"],
  },
  {
    id: 18,
    name: "Daniel Wilson",
    team: "HR Team",
    position: "Recruiter",
    email: "daniel.wilson@company.com",
    phone: "+1 (555) 123-4584",
    checkIn: "08:20 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 40m",
    activeTasks: 3,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-02-14",
    department: "Human Resources",
    salary: "$68,000",
    skills: ["Talent Acquisition", "Interviewing", "LinkedIn", "Networking"],
  },
  {
    id: 19,
    name: "Michelle Taylor",
    team: "HR Team",
    position: "HR Coordinator",
    email: "michelle.taylor@company.com",
    phone: "+1 (555) 123-4585",
    checkIn: "08:45 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 15m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2023-03-27",
    department: "Human Resources",
    salary: "$58,000",
    skills: ["Administrative Support", "Employee Records", "Payroll", "Communication"],
  },
  {
    id: 20,
    name: "James Robinson",
    team: "HR Team",
    position: "Learning & Development Specialist",
    email: "james.robinson@company.com",
    phone: "+1 (555) 123-4586",
    checkIn: "09:10 AM",
    checkOut: "-",
    status: "present",
    statusType: "late",
    hoursWorked: "0h 50m",
    activeTasks: 1,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-10-09",
    department: "Human Resources",
    salary: "$75,000",
    skills: ["Training Design", "LMS", "Performance Management", "Career Development"],
  },

  // Finance Team (5 employees)
  {
    id: 21,
    name: "David Wilson",
    team: "Finance Team",
    position: "Finance Manager",
    email: "david.wilson@company.com",
    phone: "+1 (555) 123-4587",
    checkIn: "08:00 AM",
    checkOut: "06:00 PM",
    status: "present",
    statusType: "ontime",
    hoursWorked: "8h 0m",
    activeTasks: 0,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2020-03-12",
    department: "Finance",
    salary: "$125,000",
    skills: ["Financial Planning", "Budgeting", "Analysis", "Leadership"],
  },
  {
    id: 22,
    name: "Jessica Adams",
    team: "Finance Team",
    position: "Senior Accountant",
    email: "jessica.adams@company.com",
    phone: "+1 (555) 123-4588",
    checkIn: "08:30 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 30m",
    activeTasks: 2,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2021-01-25",
    department: "Finance",
    salary: "$85,000",
    skills: ["Accounting", "QuickBooks", "Tax Preparation", "Auditing"],
  },
  {
    id: 23,
    name: "Christopher Lee",
    team: "Finance Team",
    position: "Financial Analyst",
    email: "christopher.lee@company.com",
    phone: "+1 (555) 123-4589",
    checkIn: "08:15 AM",
    checkOut: "-",
    status: "present",
    statusType: "ontime",
    hoursWorked: "1h 45m",
    activeTasks: 3,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2022-05-30",
    department: "Finance",
    salary: "$78,000",
    skills: ["Financial Modeling", "Excel", "Forecasting", "Reporting"],
  },
  {
    id: 24,
    name: "Nicole Johnson",
    team: "Finance Team",
    position: "Accounts Payable Specialist",
    email: "nicole.johnson@company.com",
    phone: "+1 (555) 123-4590",
    checkIn: "09:05 AM",
    checkOut: "-",
    status: "present",
    statusType: "late",
    hoursWorked: "0h 55m",
    activeTasks: 1,
    overdueTasks: 0,
    leaveStatus: "available",
    joinDate: "2023-04-17",
    department: "Finance",
    salary: "$62,000",
    skills: ["Accounts Payable", "Invoice Processing", "Vendor Management", "ERP Systems"],
  },
  {
    id: 25,
    name: "Steven Clark",
    team: "Finance Team",
    position: "Junior Financial Analyst",
    email: "steven.clark@company.com",
    phone: "+1 (555) 123-4591",
    checkIn: "-",
    checkOut: "-",
    status: "absent",
    statusType: "absent",
    hoursWorked: "0h 0m",
    activeTasks: 1,
    overdueTasks: 0,
    leaveStatus: "personal-leave",
    joinDate: "2023-08-21",
    department: "Finance",
    salary: "$58,000",
    skills: ["Financial Analysis", "Data Entry", "Research", "Excel"],
  },
]

// Update attendance data to reflect 25 employees
const attendanceData = {
  totalEmployees: 25,
  totalPresent: 20,
  totalAbsent: 5,
  lateArrivals: 6,
  clockedIn: 19,
  clockedOut: 1,
  onLeave: 4,
}

// Update teams data to reflect actual employee counts
const teams = [
  {
    id: 1,
    name: "AI Team",
    members: 8,
    present: 6,
    lead: "Sarah Johnson",
    currentProject: "AI Chatbot Development",
    projectProgress: 75,
    budget: "$150,000",
  },
  {
    id: 2,
    name: "BA Team",
    members: 7,
    present: 6,
    lead: "Mike Davis",
    currentProject: "Business Analytics Platform",
    projectProgress: 45,
    budget: "$200,000",
  },
  {
    id: 3,
    name: "HR Team",
    members: 5,
    present: 4,
    lead: "Emily Brown",
    currentProject: "HR Management System",
    projectProgress: 30,
    budget: "$80,000",
  },
  {
    id: 4,
    name: "Finance Team",
    members: 5,
    present: 4,
    lead: "David Wilson",
    currentProject: "Financial Reporting System",
    projectProgress: 60,
    budget: "$120,000",
  },
]

// Update recent activity to include more employees
const recentActivity = [
  { id: 1, name: "John Smith", team: "AI Team", action: "Checked In", time: "09:15 AM", status: "late" },
  { id: 2, name: "Sarah Johnson", team: "AI Team", action: "Completed Task", time: "09:10 AM", status: "task" },
  { id: 3, name: "Mike Davis", team: "BA Team", action: "Checked In", time: "08:45 AM", status: "ontime" },
  { id: 4, name: "Emily Brown", team: "HR Team", action: "Started Task", time: "09:30 AM", status: "task" },
  { id: 5, name: "David Wilson", team: "Finance Team", action: "Checked Out", time: "06:00 PM", status: "ontime" },
  { id: 6, name: "Lisa Garcia", team: "AI Team", action: "Task Overdue", time: "08:30 AM", status: "overdue" },
  { id: 7, name: "Amanda Foster", team: "BA Team", action: "Checked In", time: "09:20 AM", status: "late" },
  { id: 8, name: "Nicole Johnson", team: "Finance Team", action: "Checked In", time: "09:05 AM", status: "late" },
  { id: 9, name: "Emma Chen", team: "AI Team", action: "Completed Task", time: "08:45 AM", status: "task" },
  { id: 10, name: "Daniel Wilson", team: "HR Team", action: "Started Interview", time: "08:20 AM", status: "task" },
]

// Update leave requests with more employees
const leaveRequests = [
  {
    id: 1,
    employee: "Lisa Garcia",
    team: "AI Team",
    startDate: "2024-02-15",
    endDate: "2024-02-17",
    reason: "Personal",
    status: "approved",
  },
  {
    id: 2,
    employee: "Rachel Green",
    team: "BA Team",
    startDate: "2024-02-12",
    endDate: "2024-02-16",
    reason: "Vacation",
    status: "approved",
  },
  {
    id: 3,
    employee: "Marcus Thompson",
    team: "AI Team",
    startDate: "2024-02-10",
    endDate: "2024-02-12",
    reason: "Medical",
    status: "approved",
  },
  {
    id: 4,
    employee: "Steven Clark",
    team: "Finance Team",
    startDate: "2024-02-08",
    endDate: "2024-02-09",
    reason: "Personal",
    status: "pending",
  },
  {
    id: 5,
    employee: "Jennifer Lee",
    team: "BA Team",
    startDate: "2024-02-20",
    endDate: "2024-02-22",
    reason: "Vacation",
    status: "pending",
  },
]

// Update tasks with more realistic assignments
const allTasks = [
  {
    id: 1,
    title: "ML Model Training",
    assignee: "John Smith",
    team: "AI Team",
    project: "AI Chatbot Development",
    priority: "High",
    status: "in-progress",
    dueDate: "2024-02-10",
    description: "Train the natural language processing model",
  },
  {
    id: 2,
    title: "Database Schema Design",
    assignee: "Mike Davis",
    team: "BA Team",
    project: "Business Analytics Platform",
    priority: "Medium",
    status: "completed",
    dueDate: "2024-02-05",
    description: "Design the database structure for analytics",
  },
  {
    id: 3,
    title: "UI/UX Design",
    assignee: "Sarah Johnson",
    team: "AI Team",
    project: "AI Chatbot Development",
    priority: "High",
    status: "in-progress",
    dueDate: "2024-02-12",
    description: "Create user interface designs",
  },
  {
    id: 4,
    title: "Employee Portal Development",
    assignee: "Emily Brown",
    team: "HR Team",
    project: "HR Management System",
    priority: "Medium",
    status: "in-progress",
    dueDate: "2024-02-20",
    description: "Develop employee self-service portal",
  },
  {
    id: 5,
    title: "Data Pipeline Setup",
    assignee: "Alex Rodriguez",
    team: "AI Team",
    project: "AI Chatbot Development",
    priority: "High",
    status: "not-started",
    dueDate: "2024-02-14",
    description: "Set up data processing pipeline",
  },
  {
    id: 6,
    title: "Requirements Documentation",
    assignee: "Tom Anderson",
    team: "BA Team",
    project: "Business Analytics Platform",
    priority: "Medium",
    status: "in-progress",
    dueDate: "2024-02-18",
    description: "Document business requirements",
  },
  {
    id: 7,
    title: "Financial Report Automation",
    assignee: "Christopher Lee",
    team: "Finance Team",
    project: "Financial Reporting System",
    priority: "High",
    status: "in-progress",
    dueDate: "2024-02-25",
    description: "Automate monthly financial reports",
  },
  {
    id: 8,
    title: "Recruitment Process Optimization",
    assignee: "Daniel Wilson",
    team: "HR Team",
    project: "HR Management System",
    priority: "Low",
    status: "not-started",
    dueDate: "2024-03-01",
    description: "Optimize the recruitment workflow",
  },
  {
    id: 9,
    title: "Model Deployment",
    assignee: "Emma Chen",
    team: "AI Team",
    project: "AI Chatbot Development",
    priority: "High",
    status: "completed",
    dueDate: "2024-02-08",
    description: "Deploy ML model to production",
  },
  {
    id: 10,
    title: "Budget Analysis",
    assignee: "Jessica Adams",
    team: "Finance Team",
    project: "Financial Reporting System",
    priority: "Medium",
    status: "in-progress",
    dueDate: "2024-02-22",
    description: "Analyze quarterly budget performance",
  },
  {
    id: 11,
    title: "User Testing",
    assignee: "Jennifer Lee",
    team: "BA Team",
    project: "Business Analytics Platform",
    priority: "Medium",
    status: "not-started",
    dueDate: "2024-02-28",
    description: "Conduct user acceptance testing",
  },
  {
    id: 12,
    title: "Training Material Creation",
    assignee: "James Robinson",
    team: "HR Team",
    project: "HR Management System",
    priority: "Low",
    status: "not-started",
    dueDate: "2024-03-05",
    description: "Create training materials for new system",
  },
]

const projectDeadlines = [
  {
    id: 1,
    project: "AI Chatbot Development",
    deadline: "2024-02-29",
    daysLeft: 7,
    status: "urgent",
  },
  {
    id: 2,
    project: "Business Analytics Platform",
    deadline: "2024-03-05",
    daysLeft: 12,
    status: "on-track",
  },
  {
    id: 3,
    project: "HR Management System",
    deadline: "2024-03-10",
    daysLeft: 17,
    status: "on-track",
  },
  {
    id: 4,
    project: "Financial Reporting System",
    deadline: "2024-03-15",
    daysLeft: 22,
    status: "on-track",
  },
]

const notifications = [
  {
    id: 1,
    title: "New Task Assigned",
    message: "A new task 'Design Database Schema' has been assigned to you.",
    time: "2 hours ago",
    type: "info",
  },
  {
    id: 2,
    title: "Project Deadline Approaching",
    message: "The 'AI Chatbot Development' project deadline is approaching in 7 days.",
    time: "5 hours ago",
    type: "warning",
  },
  {
    id: 3,
    title: "Leave Request Approved",
    message: "Your leave request for 2024-02-15 to 2024-02-17 has been approved.",
    time: "1 day ago",
    type: "success",
  },
]

export default function ComprehensiveDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [searchTerm, setSearchTerm] = useState("")
  const [teamFilter, setTeamFilter] = useState("all")
  const [taskFilter, setTaskFilter] = useState("all")
  const [newTaskOpen, setNewTaskOpen] = useState(false)
  const [newMemberOpen, setNewMemberOpen] = useState(false)
  const [leaveRequestOpen, setLeaveRequestOpen] = useState(false)
  const [clockInOut, setClockInOut] = useState(false)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "not-started":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Not Started</Badge>
      case "in-progress":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">In Progress</Badge>
      case "completed":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>
      case "approved":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "High":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">High</Badge>
      case "Medium":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Medium</Badge>
      case "Low":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Low</Badge>
      default:
        return <Badge variant="secondary">Normal</Badge>
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case "info":
        return <Bell className="h-4 w-4 text-blue-500" />
      default:
        return <Bell className="h-4 w-4 text-gray-500" />
    }
  }

  const filteredTasks = allTasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.assignee.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = taskFilter === "all" || task.status === taskFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="border-b bg-white/80 backdrop-blur-sm">
        <div className="flex h-16 items-center px-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Briefcase className="h-6 w-6 text-blue-600" />
              <h1 className="text-xl font-semibold text-gray-900">Enterprise Dashboard</h1>
            </div>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <Dialog open={clockInOut} onOpenChange={setClockInOut}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Clock className="h-4 w-4 mr-2" />
                  Clock In/Out
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Clock In/Out</DialogTitle>
                  <DialogDescription>Record your attendance for today</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{new Date().toLocaleTimeString()}</div>
                    <div className="text-sm text-muted-foreground">{new Date().toLocaleDateString()}</div>
                  </div>
                  <div className="flex space-x-2">
                    <Button className="flex-1" onClick={() => setClockInOut(false)}>
                      <LogIn className="h-4 w-4 mr-2" />
                      Clock In
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent" onClick={() => setClockInOut(false)}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Clock Out
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <div className="text-sm text-muted-foreground">
              {new Date().toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white/50 backdrop-blur-sm">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Present</CardTitle>
                  <Users className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{attendanceData.totalPresent}</div>
                  <p className="text-xs text-muted-foreground">
                    {((attendanceData.totalPresent / attendanceData.totalEmployees) * 100).toFixed(1)}% attendance
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
                  <Target className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{teams.length}</div>
                  <p className="text-xs text-muted-foreground">Across all teams</p>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tasks In Progress</CardTitle>
                  <ClipboardList className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">
                    {allTasks.filter((task) => task.status === "in-progress").length}
                  </div>
                  <p className="text-xs text-muted-foreground">Active tasks</p>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Upcoming Deadlines</CardTitle>
                  <AlertCircle className="h-4 w-4 text-red-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">
                    {projectDeadlines.filter((p) => p.daysLeft <= 7).length}
                  </div>
                  <p className="text-xs text-muted-foreground">Within 7 days</p>
                </CardContent>
              </Card>
            </div>

            {/* Project Deadlines */}
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Project Deadlines</CardTitle>
                <CardDescription>Upcoming project milestones and deadlines</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {projectDeadlines.map((project) => (
                    <div key={project.id} className="flex items-center justify-between p-4 rounded-lg bg-gray-50/50">
                      <div>
                        <h4 className="font-medium">{project.project}</h4>
                        <p className="text-sm text-muted-foreground">Due: {project.deadline}</p>
                      </div>
                      <div className="text-right">
                        <div
                          className={`text-sm font-medium ${project.status === "urgent" ? "text-red-600" : "text-blue-600"}`}
                        >
                          {project.daysLeft} days left
                        </div>
                        <Badge
                          className={
                            project.status === "urgent" ? "bg-red-100 text-red-800" : "bg-blue-100 text-blue-800"
                          }
                        >
                          {project.status === "urgent" ? "Urgent" : "On Track"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Attendance Tab */}
          <TabsContent value="attendance" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-3">
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Clocked In</CardTitle>
                  <LogIn className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{attendanceData.clockedIn}</div>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Clocked Out</CardTitle>
                  <LogOut className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{attendanceData.clockedOut}</div>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">On Leave</CardTitle>
                  <Calendar className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{attendanceData.onLeave}</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Leave Requests</CardTitle>
                  <CardDescription>Pending and approved leave requests</CardDescription>
                  <Dialog open={leaveRequestOpen} onOpenChange={setLeaveRequestOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm">
                        <Plus className="h-4 w-4 mr-2" />
                        Request Leave
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Submit Leave Request</DialogTitle>
                        <DialogDescription>Fill in the details for your leave request</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="start-date">Start Date</Label>
                            <Input id="start-date" type="date" />
                          </div>
                          <div>
                            <Label htmlFor="end-date">End Date</Label>
                            <Input id="end-date" type="date" />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="reason">Reason</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select reason" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="personal">Personal</SelectItem>
                              <SelectItem value="medical">Medical</SelectItem>
                              <SelectItem value="vacation">Vacation</SelectItem>
                              <SelectItem value="emergency">Emergency</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="description">Description</Label>
                          <Textarea id="description" placeholder="Additional details..." />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={() => setLeaveRequestOpen(false)}>Submit Request</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {leaveRequests.map((request) => (
                      <div key={request.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50/50">
                        <div>
                          <h4 className="font-medium">{request.employee}</h4>
                          <p className="text-sm text-muted-foreground">
                            {request.startDate} to {request.endDate} • {request.reason}
                          </p>
                        </div>
                        {getStatusBadge(request.status)}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Today's Clock In/Out</CardTitle>
                  <CardDescription>Real-time attendance tracking</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50/50">
                      <div className="flex items-center space-x-3">
                        <LogIn className="h-4 w-4 text-green-600" />
                        <div>
                          <p className="font-medium">Sarah Johnson</p>
                          <p className="text-sm text-muted-foreground">AI Team Lead</p>
                        </div>
                      </div>
                      <div className="text-sm text-green-600 font-medium">08:30 AM</div>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50/50">
                      <div className="flex items-center space-x-3">
                        <LogOut className="h-4 w-4 text-blue-600" />
                        <div>
                          <p className="font-medium">Mike Davis</p>
                          <p className="text-sm text-muted-foreground">BA Team Lead</p>
                        </div>
                      </div>
                      <div className="text-sm text-blue-600 font-medium">06:15 PM</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Task Management</CardTitle>
                <CardDescription>Organize and track all project tasks</CardDescription>
                <div className="flex space-x-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search tasks..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                  <Select value={taskFilter} onValueChange={setTaskFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter by Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Tasks</SelectItem>
                      <SelectItem value="not-started">Not Started</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <Dialog open={newTaskOpen} onOpenChange={setNewTaskOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        New Task
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create New Task</DialogTitle>
                        <DialogDescription>Add a new task to the project</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="task-title">Task Title</Label>
                          <Input id="task-title" placeholder="Enter task title" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="assignee">Assignee</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select assignee" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="sarah">Sarah Johnson</SelectItem>
                                <SelectItem value="john">John Smith</SelectItem>
                                <SelectItem value="lisa">Lisa Garcia</SelectItem>
                                <SelectItem value="alex">Alex Rodriguez</SelectItem>
                                <SelectItem value="emma">Emma Chen</SelectItem>
                                <SelectItem value="ryan">Ryan Park</SelectItem>
                                <SelectItem value="sophia">Sophia Williams</SelectItem>
                                <SelectItem value="marcus">Marcus Thompson</SelectItem>
                                <SelectItem value="mike">Mike Davis</SelectItem>
                                <SelectItem value="tom">Tom Anderson</SelectItem>
                                <SelectItem value="jennifer">Jennifer Lee</SelectItem>
                                <SelectItem value="robert">Robert Kim</SelectItem>
                                <SelectItem value="amanda">Amanda Foster</SelectItem>
                                <SelectItem value="kevin">Kevin Martinez</SelectItem>
                                <SelectItem value="rachel">Rachel Green</SelectItem>
                                <SelectItem value="emily">Emily Brown</SelectItem>
                                <SelectItem value="anna">Anna Martinez</SelectItem>
                                <SelectItem value="daniel">Daniel Wilson</SelectItem>
                                <SelectItem value="michelle">Michelle Taylor</SelectItem>
                                <SelectItem value="james">James Robinson</SelectItem>
                                <SelectItem value="david">David Wilson</SelectItem>
                                <SelectItem value="jessica">Jessica Adams</SelectItem>
                                <SelectItem value="christopher">Christopher Lee</SelectItem>
                                <SelectItem value="nicole">Nicole Johnson</SelectItem>
                                <SelectItem value="steven">Steven Clark</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="priority">Priority</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select priority" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="due-date">Due Date</Label>
                          <Input id="due-date" type="date" />
                        </div>
                        <div>
                          <Label htmlFor="description">Description</Label>
                          <Textarea id="description" placeholder="Task description..." />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={() => setNewTaskOpen(false)}>Create Task</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="all">All Tasks</TabsTrigger>
                    <TabsTrigger value="not-started">Not Started</TabsTrigger>
                    <TabsTrigger value="in-progress">In Progress</TabsTrigger>
                    <TabsTrigger value="completed">Completed</TabsTrigger>
                  </TabsList>
                  <TabsContent value="all" className="space-y-4">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Task</TableHead>
                          <TableHead>Assignee</TableHead>
                          <TableHead>Project</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Due Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredTasks.map((task) => (
                          <TableRow key={task.id}>
                            <TableCell className="font-medium">{task.title}</TableCell>
                            <TableCell>{task.assignee}</TableCell>
                            <TableCell>{task.project}</TableCell>
                            <TableCell>{getPriorityBadge(task.priority)}</TableCell>
                            <TableCell>{getStatusBadge(task.status)}</TableCell>
                            <TableCell>{task.dueDate}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                  <TabsContent value="not-started">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Task</TableHead>
                          <TableHead>Assignee</TableHead>
                          <TableHead>Project</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Due Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allTasks
                          .filter((task) => task.status === "not-started")
                          .map((task) => (
                            <TableRow key={task.id}>
                              <TableCell className="font-medium">{task.title}</TableCell>
                              <TableCell>{task.assignee}</TableCell>
                              <TableCell>{task.project}</TableCell>
                              <TableCell>{getPriorityBadge(task.priority)}</TableCell>
                              <TableCell>{task.dueDate}</TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                  <TabsContent value="in-progress">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Task</TableHead>
                          <TableHead>Assignee</TableHead>
                          <TableHead>Project</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Due Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allTasks
                          .filter((task) => task.status === "in-progress")
                          .map((task) => (
                            <TableRow key={task.id}>
                              <TableCell className="font-medium">{task.title}</TableCell>
                              <TableCell>{task.assignee}</TableCell>
                              <TableCell>{task.project}</TableCell>
                              <TableCell>{getPriorityBadge(task.priority)}</TableCell>
                              <TableCell>{task.dueDate}</TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                  <TabsContent value="completed">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Task</TableHead>
                          <TableHead>Assignee</TableHead>
                          <TableHead>Project</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Completed Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allTasks
                          .filter((task) => task.status === "completed")
                          .map((task) => (
                            <TableRow key={task.id}>
                              <TableCell className="font-medium">{task.title}</TableCell>
                              <TableCell>{task.assignee}</TableCell>
                              <TableCell>{task.project}</TableCell>
                              <TableCell>{getPriorityBadge(task.priority)}</TableCell>
                              <TableCell>{task.dueDate}</TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Teams & Project Management</CardTitle>
                <CardDescription>Overview of team projects and progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-1">
                  {teams.map((team) => (
                    <Card key={team.id} className="border-l-4 border-l-blue-500">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-lg">{team.name}</CardTitle>
                            <CardDescription>
                              Lead: {team.lead} • {team.members} members
                            </CardDescription>
                          </div>
                          <Dialog open={newMemberOpen} onOpenChange={setNewMemberOpen}>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <UserPlus className="h-4 w-4 mr-2" />
                                Add Member
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Add Team Member</DialogTitle>
                                <DialogDescription>Add a new member to {team.name}</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label htmlFor="member-name">Full Name</Label>
                                  <Input id="member-name" placeholder="Enter full name" />
                                </div>
                                <div>
                                  <Label htmlFor="member-email">Email</Label>
                                  <Input id="member-email" type="email" placeholder="Enter email address" />
                                </div>
                                <div>
                                  <Label htmlFor="member-role">Role</Label>
                                  <Input id="member-role" placeholder="Enter role/position" />
                                </div>
                                <div>
                                  <Label htmlFor="member-skills">Skills</Label>
                                  <Textarea id="member-skills" placeholder="List relevant skills..." />
                                </div>
                              </div>
                              <DialogFooter>
                                <Button onClick={() => setNewMemberOpen(false)}>Add Member</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="font-medium">Current Project: {team.currentProject}</span>
                            <span className="text-muted-foreground">{team.projectProgress}% Complete</span>
                          </div>
                          <Progress value={team.projectProgress} className="h-2" />
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Team Size:</span>
                            <div className="font-medium">{team.members} members</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Present Today:</span>
                            <div className="font-medium text-green-600">{team.present}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Budget:</span>
                            <div className="font-medium">{team.budget}</div>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">Team Members Working on Project:</h4>
                          <div className="flex flex-wrap gap-2">
                            {allTasks
                              .filter((task) => task.team === team.name)
                              .map((task) => task.assignee)
                              .filter((assignee, index, self) => self.indexOf(assignee) === index)
                              .map((assignee, index) => (
                                <Badge key={index} variant="outline" className="text-blue-600">
                                  {assignee}
                                </Badge>
                              ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Company Notifications</CardTitle>
                <CardDescription>Recent happenings and important updates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div key={notification.id} className="flex items-start space-x-4 p-4 rounded-lg bg-gray-50/50">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium">{notification.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                        <p className="text-xs text-muted-foreground mt-2">{notification.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Dashboard Settings</CardTitle>
                <CardDescription>Customize your dashboard experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Appearance</h3>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-base">Theme</Label>
                      <p className="text-sm text-muted-foreground mb-2">Choose your preferred theme</p>
                      <Select defaultValue="professional">
                        <SelectTrigger className="w-48">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="professional">Professional</SelectItem>
                          <SelectItem value="modern">Modern</SelectItem>
                          <SelectItem value="minimal">Minimal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-base">Background Style</Label>
                      <p className="text-sm text-muted-foreground mb-2">Current: Professional gradient background</p>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Solid
                        </Button>
                        <Button variant="outline" size="sm">
                          Gradient
                        </Button>
                        <Button size="sm">Professional</Button>
                      </div>
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <h3 className="text-lg font-medium mb-4">Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Email Notifications</Label>
                        <p className="text-sm text-muted-foreground">Receive updates via email</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Configure
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Push Notifications</Label>
                        <p className="text-sm text-muted-foreground">Browser notifications for urgent updates</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Enable
                      </Button>
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <h3 className="text-lg font-medium mb-4">Data & Privacy</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Export Data</Label>
                        <p className="text-sm text-muted-foreground">Download your dashboard data</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
